import React from "react";

export default function Favorites() {
  return <div className="screen-container">Favorites</div>;
}
