import React from "react";
import Home from "./screens/home";

export default function App() {
  return (
    <div>
      <Home />
    </div>
  );
}
